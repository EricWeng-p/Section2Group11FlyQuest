
#include <stdio.h>
#include <string.h>
#include "ticketGenerator.h"

int main(void) {
	TICKET t;
	srand(time(NULL));
	printf("%d\n", getGate());
	printf("%c\n", getHex());
	printf("%c\n", getTime());
	t = tempTicketGenerator();
	getTicket(t);
	ticketPrinter(t);

}